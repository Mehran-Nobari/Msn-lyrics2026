package com.example.btnapp;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.UriPermission;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.documentfile.provider.DocumentFile;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 1;
    private static final int REQ_DIR = 2;

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private SharedPreferences prefs;
    private Uri treeUri;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        prefs = getSharedPreferences("msn", MODE_PRIVATE);
        String saved = prefs.getString("tree", null);
        treeUri = saved == null ? null : Uri.parse(saved);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String path = u.getPath();
                // فایل‌های آهنگ از پوشه انتخاب‌شده
                if (path != null && path.startsWith("/music/") && treeUri != null) {
                    try {
                        String id = path.substring(7);
                        Uri doc = DocumentsContract.buildDocumentUriUsingTree(treeUri, id);
                        InputStream in = getContentResolver().openInputStream(doc);
                        String mime = getContentResolver().getType(doc);
                        if (mime == null) mime = "application/octet-stream";
                        Map<String, String> h = new HashMap<>();
                        h.put("Access-Control-Allow-Origin", "*");
                        return new WebResourceResponse(mime, null, 200, "OK", h, in);
                    } catch (Exception e) {
                        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                                new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                    }
                }
                return loader.shouldInterceptRequest(u);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try {
                    startActivityForResult(p.createIntent(), REQ_FILE);
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE) {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                fileCb = null;
            }
            return;
        }
        if (req == REQ_DIR) {
            String name = "";
            boolean ok = false;
            if (res == RESULT_OK && data != null && data.getData() != null) {
                try {
                    Uri uri = data.getData();
                    getContentResolver().takePersistableUriPermission(uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    treeUri = uri;
                    prefs.edit().putString("tree", uri.toString()).apply();
                    name = folderName();
                    ok = true;
                } catch (Exception e) {
                    ok = false;
                }
            }
            web.evaluateJavascript("window.__nativeDir && window.__nativeDir(" + ok + "," + JSONObject.quote(name) + ")", null);
            return;
        }
        super.onActivityResult(req, res, data);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    // نام پوشه انتخاب‌شده؛ اگر دسترسی نباشد رشته خالی
    private String folderName() {
        if (treeUri == null) return "";
        boolean ok = false;
        for (UriPermission p : getContentResolver().getPersistedUriPermissions()) {
            if (p.getUri().toString().equals(treeUri.toString()) && p.isReadPermission() && p.isWritePermission()) {
                ok = true;
            }
        }
        if (!ok) return "";
        DocumentFile d = DocumentFile.fromTreeUri(this, treeUri);
        String n = d == null ? null : d.getName();
        return n == null || n.isEmpty() ? "پوشه" : n;
    }

    private class Bridge {
        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> finishAffinity());
        }

        // ذخیره فایل در پوشه Download گوشی
        @JavascriptInterface
        public boolean saveFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return false;
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    os.write(data);
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        // باز کردن انتخاب پوشه (نتیجه با window.__nativeDir برمی‌گردد)
        @JavascriptInterface
        public void pickDir() {
            runOnUiThread(() -> {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                try {
                    startActivityForResult(i, REQ_DIR);
                } catch (Exception e) {
                    web.evaluateJavascript("window.__nativeDir && window.__nativeDir(false,\"\")", null);
                }
            });
        }

        @JavascriptInterface
        public String dirName() {
            return folderName();
        }

        // فهرست محتویات یک پوشه: [{id, n, d}]
        @JavascriptInterface
        public String listDir(String docId) {
            JSONArray arr = new JSONArray();
            if (treeUri == null) return arr.toString();
            Cursor c = null;
            try {
                String parent = (docId == null || docId.isEmpty())
                        ? DocumentsContract.getTreeDocumentId(treeUri) : docId;
                Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parent);
                c = getContentResolver().query(children, new String[]{
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null, null);
                if (c != null) {
                    while (c.moveToNext()) {
                        JSONObject o = new JSONObject();
                        o.put("id", c.getString(0));
                        o.put("n", c.getString(1));
                        o.put("d", DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2)));
                        arr.put(o);
                    }
                }
            } catch (Exception e) {
                // خالی برمی‌گردد
            } finally {
                if (c != null) c.close();
            }
            return arr.toString();
        }

        // نوشتن فایل (مثل بکاپ) داخل پوشه انتخاب‌شده
        @JavascriptInterface
        public boolean writeFile(String name, String base64) {
            if (treeUri == null) return false;
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                DocumentFile dir = DocumentFile.fromTreeUri(MainActivity.this, treeUri);
                if (dir == null) return false;
                DocumentFile f = dir.findFile(name);
                if (f == null) f = dir.createFile("application/json", name);
                if (f == null) return false;
                try (OutputStream os = getContentResolver().openOutputStream(f.getUri(), "wt")) {
                    os.write(data);
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
